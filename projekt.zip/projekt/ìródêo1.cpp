#include <Windows.h>
#include <string>
#include <array>
#include <cstdio>
#include <  >




using namespace std;


class pracownik {
	string imie, nazwisko, stanowisko;
	double pensja brutto;
};




int main() {

	cout << "MENU" << endl << "1. Dodaj pracownika" << endl << "2. Wy�wietl pracownik�w" << endl << "3. Usu� pracownika" << endl << "4. Edytuj pracownika" << endl;

	switch (menu) {

		case 1:
				
			break;

		case 2:

			break;

		case 3:

			break;

		case 4:
			cout << "wybierz pracownika" << endl;
			cin >> numer_pracownik;

			cout << "co chcesz zmieni�?" << "1.Imie" << "2.Nazwisko " << "3.Stanowisko" << "4.Wyp�ate brutto" << endl;
			cin >> decyzja_zmiana;
			switch (decyzja_zmiana) {

			case 1
				cout << "zmie� imie" << endl;
				cin >> zmiana_imie;
				break;

			case 2
				cout << "zmie� nazwisko" << endl;
				cin >> zmiana_nazwisko;
				break;

			case 3
				cout << "zmie� stanowisko" << endl;
				cin >> zmiana_stanowisko;
				break;

			case 4
				cout << "zmien pensje brutto" << endl;
				cin >> zmiana_pensja;
				break;
			}




		cout << "zmie� imie" << endl;
		cin >> zmiana_imie;
		cout<< "zmie� nazwisko"<<endl;
		cin >> zmiana_nazwisko;
		cout << "zmie� stanowisko" << endl;
		cin >> zmiana_stanowisko;
		cout << "zmien pensje brutto" << endl;
		break;

	default:
		cout << "�le wpisa�e�, spr�buj ponownie" << endl;
	}

}